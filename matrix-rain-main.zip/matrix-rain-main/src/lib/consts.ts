export const FPS = 30
export const HEIGHT = 1080
export const WIDTH = 1920
